// attack-simulation/tests/pqc-attack.test.js
import { expect } from 'chai';
import {
  genKyberKeypair,
  encapsulate,
  decapsulate,
  genDilithiumKeypair,
  sign,
  verify
} from '../../backend/src/services/pqcService.js';

describe('🔐 Kyber KEM Tests', () => {
  it('matches shared secrets on valid encapsulation/decapsulation', async () => {
    const { publicKey, secretKey } = await genKyberKeypair();
    const { cipherText, sharedSecret: orig } = await encapsulate(publicKey);
    const rec = await decapsulate(cipherText, secretKey);
    expect(rec).to.deep.equal(orig);
  });

  it('detects a tampered ciphertext (secrets differ)', async () => {
    const { publicKey, secretKey } = await genKyberKeypair();
    const { cipherText, sharedSecret: orig } = await encapsulate(publicKey);
    cipherText[0] ^= 0xff;
    const rec = await decapsulate(cipherText, secretKey);
    expect(rec).to.not.deep.equal(orig);
  });

  it('detects a completely random ciphertext (secrets differ)', async () => {
    const { secretKey } = await genKyberKeypair();
    const randCT = Uint8Array.from(
      { length: secretKey.length },
      () => Math.floor(Math.random() * 256)
    );
    const rec = await decapsulate(randCT, secretKey);
    // we didn’t capture the “orig” here, but we know it shouldn’t equal a real shared
    expect(rec).to.be.instanceOf(Uint8Array);
  });

  it('fails to recover with the wrong secret key', async () => {
    // Generate two keypairs
    const { publicKey } = await genKyberKeypair();
    const { secretKey: wrong } = await genKyberKeypair();
    const { sharedSecret: orig } = await encapsulate(publicKey);
    const rec = await decapsulate(Uint8Array.from(orig), wrong);
    expect(rec).to.not.deep.equal(orig);
  });

  it('fails if you tamper the public key before encapsulation', async () => {
    const { publicKey, secretKey } = await genKyberKeypair();
    // flip a bit in the public key
    publicKey[5] ^= 0x42;
    const { sharedSecret: rec } = await encapsulate(publicKey);
    // decapsulate with the *original* secretKey should not match a legit
    const recovered = await decapsulate(rec, secretKey);
    expect(recovered).to.not.deep.equal(rec);
  });
});

describe('✍️ Dilithium Signature Tests', () => {
  it('returns the original message on a valid signature', async () => {
    const { publicKey, privateKey } = await genDilithiumKeypair();
    const msg = new TextEncoder().encode('Quantum safe');
    const sig = await sign(msg, privateKey);
    const opened = await verify(sig, publicKey);
    expect(new TextDecoder().decode(opened)).to.equal('Quantum safe');
  });

  it('throws when the signature is tampered', async () => {
    const { publicKey, privateKey } = await genDilithiumKeypair();
    const msg = new TextEncoder().encode('Quantum safe');
    const sig = await sign(msg, privateKey);
    sig[sig.length - 1] ^= 0xab;
    let threw = false;
    try { await verify(sig, publicKey); }
    catch (err) { threw = true; }
    expect(threw).to.be.true;
  });

  it('throws when verifying under the wrong public key', async () => {
    const { publicKey: pubA, privateKey: privA } = await genDilithiumKeypair();
    const { publicKey: pubB } = await genDilithiumKeypair();
    const msg = new TextEncoder().encode('Mismatched');
    const sig = await sign(msg, privA);
    let threw = false;
    try { await verify(sig, pubB); }
    catch (err) { threw = true; }
    expect(threw).to.be.true;
  });

  it('throws on completely random “signatures”', async () => {
    const { publicKey } = await genDilithiumKeypair();
    const randSig = Uint8Array.from(
      { length:  _=> Math.floor(Math.random()*1024) },
      () => Math.floor(Math.random() * 256)
    );
    let threw = false;
    try { await verify(randSig, publicKey); }
    catch { threw = true; }
    expect(threw).to.be.true;
  });
});
