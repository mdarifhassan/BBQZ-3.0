import React, { useState } from 'react';
import ZKProof from './ZKProof';

function KeyGenerator() {
  const [generatedKeys, setGeneratedKeys] = useState(null);
  const [showProofSection, setShowProofSection] = useState(false);

  const handleGenerateKeys = async () => {
    // ... existing logic to call backend for key generation ...
    // Assume it sets the state `generatedKeys` with { publicKey: '...', ... }
    const keys = await fetch('/api/generate-keys').then(res => res.json());
    setGeneratedKeys(keys);
    setShowProofSection(false);
  };

  return (
    <div>
      <h2>Key Generation</h2>
      <button onClick={handleGenerateKeys}>Generate New Keys</button>

      {generatedKeys && (
        <div className="keys-output" style={{ marginTop: '1rem' }}>
          <p><strong>Public Key:</strong> {generatedKeys.publicKey}</p>
          {/* Other key details if any... */}
          
          {/* New: Button to reveal ZK proof section */}
          <button onClick={() => setShowProofSection(true)} style={{ marginTop: '0.5rem' }}>
            Generate ZK Proof for this Key
          </button>

          {/* Conditionally render the ZKProof component */}
          {showProofSection && (
            <ZKProof publicKey={generatedKeys.publicKey} />
          )}
        </div>
      )}
    </div>
  );
}

export default KeyGenerator;
