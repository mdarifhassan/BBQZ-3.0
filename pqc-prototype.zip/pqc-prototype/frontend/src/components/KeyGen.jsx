// frontend/src/components/KeyGen.jsx
import React, { useState } from 'react';
import ZKProof from './ZKProof';

export default function KeyGen() {
  const [userId,    setUserId]   = useState('');
  const [loading,   setLoading]  = useState(false);
  const [keys,      setKeys]     = useState(null);
  const [privates,  setPrivates] = useState(null);
  const [error,     setError]    = useState('');
  const [metrics,   setMetrics]  = useState(null);

  async function generateKeys() {
    if (!userId.trim()) {
      setError('Please enter a userId.');
      return;
    }
    setError('');
    setLoading(true);
    setKeys(null);
    setPrivates(null);
    setMetrics(null);

    const url = `http://${window.location.hostname}:3001/api/auth/register`;
    const t0  = performance.now();

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();
      const t1   = performance.now();

      // client-side metrics
      const roundTripMs = (t1 - t0).toFixed(2);
      const kChars      = data.publicKeys.kyber.length;
      const dChars      = data.publicKeys.dilithium.length;
      const kBytes      = Math.ceil((kChars * 3) / 4);
      const dBytes      = Math.ceil((dChars * 3) / 4);

      setKeys(data.publicKeys);
      setPrivates(data.privateKeys);
      setMetrics({
        // client-side
        roundTripMs,
        kyberPubChars:     kChars,
        kyberPubBytes:     kBytes,
        dilithiumPubChars: dChars,
        dilithiumPubBytes: dBytes,
        // server-side
        kyberGenMs:           data.serverMetrics.kyberGenMs,
        dilithiumGenMs:       data.serverMetrics.dilithiumGenMs,
        kyberPubKeyBytes:     data.serverMetrics.kyberPubKeyBytes,
        kyberSecKeyBytes:     data.serverMetrics.kyberSecKeyBytes,
        dilithiumPubKeyBytes: data.serverMetrics.dilithiumPubKeyBytes,
        dilithiumPrivKeyBytes:data.serverMetrics.dilithiumPrivKeyBytes,
      });
    } catch (err) {
      console.error(err);
      setError('Failed to generate keys: ' + err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 600, fontFamily: 'sans-serif', margin: '2rem auto' }}>
      <h2>🔑 Post-Quantum Keygen</h2>

      <label>
        User ID:
        <input
          type="text"
          value={userId}
          onChange={e => setUserId(e.target.value)}
          style={{ width: '100%', margin: '0.5rem 0' }}
        />
      </label>

      <button onClick={generateKeys} disabled={loading}>
        {loading ? 'Generating…' : 'Generate Keys'}
      </button>

      {error && (
        <p style={{ color: 'red', marginTop: '1rem' }}>{error}</p>
      )}

      {/* Public Keys */}
      {keys && (
        <div style={{ marginTop: '1.5rem', wordBreak: 'break-all' }}>
          <h3>Public Keys</h3>
          <p><strong>Kyber:</strong><br/><code>{keys.kyber}</code></p>
          <p><strong>Dilithium:</strong><br/><code>{keys.dilithium}</code></p>
        </div>
      )}

      {/* Private Keys */}
      {privates && (
        <div style={{ marginTop: '1.5rem', wordBreak: 'break-all' }}>
          <h3>Private Keys <small>(demo only)</small></h3>
          <p><strong>Kyber secret:</strong><br/><code>{privates.kyber}</code></p>
          <p><strong>Dilithium private:</strong><br/><code>{privates.dilithium}</code></p>
        </div>
      )}

      {/* Keygen Metrics */}
      {metrics && (
        <div style={{ marginTop: '1.5rem' }}>
          <h3>🔎 Metrics</h3>
          <p><strong>Round-trip (client fetch + parse):</strong> {metrics.roundTripMs} ms</p>
          <p><strong>Kyber pub-key:</strong> {metrics.kyberPubBytes} B ({metrics.kyberPubChars} chars)</p>
          <p><strong>Dilithium pub-key:</strong> {metrics.dilithiumPubBytes} B ({metrics.dilithiumPubChars} chars)</p>
          <p><strong>Server Kyber gen time:</strong> {metrics.kyberGenMs} ms</p>
          <p><strong>Server Dilithium gen time:</strong> {metrics.dilithiumGenMs} ms</p>
          <p>
            <strong>Server key sizes:</strong><br/>
            Kyber pub {metrics.kyberPubKeyBytes} B, sec {metrics.kyberSecKeyBytes} B<br/>
            Dilithium pub {metrics.dilithiumPubKeyBytes} B, priv {metrics.dilithiumPrivKeyBytes} B
          </p>
        </div>
      )}

      {/* ZK-STARK Proof Section */}
      {privates && keys && (
        <div style={{ marginTop: '2rem' }}>
          <ZKProof 
            userId={userId} 
            publicKey={keys.dilithium} 
          />
        </div>
      )}
    </div>
  );
}
