// frontend/src/components/ZKProof.jsx
import React, { useState } from 'react';

export default function ZKProof({ userId, publicKey }) {
  const [proof,      setProof]      = useState(null);
  const [metrics,    setMetrics]    = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState('');

  async function handleProof() {
    setLoading(true);
    setError('');
    setProof(null);
    setMetrics(null);

    const t0 = performance.now();
    try {
      const res  = await fetch('http://localhost:3001/api/generate-proof', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
      const data = await res.json();
      const t1   = performance.now();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Proof generation failed');
      }

      // client-side round-trip time:
      const roundTripMs = +((t1 - t0).toFixed(2));

      setProof(data.publicOutput);
      setMetrics({
        roundTripMs,
        serverProofGenMs:  data.serverMetrics.proofGenMs,
        proofBytes:        data.serverMetrics.proofBytes,
        proofChars:        data.serverMetrics.proofChars
      });
    } catch (e) {
      console.error(e);
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ marginTop:'1.5rem', padding:'1rem', border:'1px solid #ddd' }}>
      <h3>🔒 ZK-STARK Proof</h3>
      <p>User ID: <strong>{userId}</strong></p>
      <button onClick={handleProof} disabled={loading}>
        {loading ? 'Proving…' : 'Generate Proof'}
      </button>

      {proof && (
        <div style={{ marginTop:'1rem', color:'green' }}>
          ✅ Proof OK. Public output: <code>{proof}</code>
        </div>
      )}
      {error && (
        <div style={{ marginTop:'1rem', color:'red' }}>
          ⚠️ {error}
        </div>
      )}

      {metrics && (
        <div style={{ marginTop:'1rem' }}>
          <h4>📊 Proof Metrics</h4>
          <p><strong>Round-trip (client):</strong> {metrics.roundTripMs} ms</p>
          <p><strong>Server proof gen:</strong> {metrics.serverProofGenMs} ms</p>
          <p><strong>Proof size:</strong> {metrics.proofBytes} bytes ({metrics.proofChars} chars)</p>
        </div>
      )}
    </div>
  );
}
