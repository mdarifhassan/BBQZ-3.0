// frontend/src/App.jsx
import React from 'react';
import KeyGen from './components/KeyGen';

// Main application component
export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Post-Quantum Keygen</h1>
      <KeyGen />
    </div>
  );
}
