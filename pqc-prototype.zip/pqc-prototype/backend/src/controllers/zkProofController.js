// backend/src/controllers/zkProofController.js
import { performance } from 'perf_hooks';
import fs         from 'fs';
import path       from 'path';
import { fileURLToPath } from 'url';
import { generateProof }  from '../../zkstark/generate_proof.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const DB_PATH    = path.resolve(__dirname, '../../db.json');

export async function generateProofHandler(req, res) {
  try {
    const { userId } = req.body;
    if (!userId) return res.status(400).json({ success:false, error:'Missing userId' });

    // load user entry
    const dbRaw = fs.readFileSync(DB_PATH, 'utf8');
    const db    = JSON.parse(dbRaw);
    const entry = db[userId];
    if (!entry?.privateKeys?.dilithium) {
      throw new Error(`No private key found for user "${userId}"`);
    }

    // decode private key
    const privBuf = Buffer.from(entry.privateKeys.dilithium, 'base64');
    const privBig = BigInt('0x' + privBuf.toString('hex'));

    // → Measure proof generation time
    const t0 = performance.now();
    const publicOutput = generateProof(privBig);
    const t1 = performance.now();
    const proofGenMs = +((t1 - t0).toFixed(2));

    // → Measure proof size
    const proofChars = publicOutput.length;
    const proofBytes = Buffer.byteLength(publicOutput, 'utf8');

    return res.json({
      success: true,
      publicOutput,
      serverMetrics: { proofGenMs, proofBytes, proofChars }
    });

  } catch (err) {
    console.error('Proof generation error:', err);
    return res.status(500).json({ success:false, error: err.message });
  }
}
