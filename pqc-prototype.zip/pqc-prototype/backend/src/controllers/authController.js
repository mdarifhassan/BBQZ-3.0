// backend/src/controllers/authController.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { genKyberKeypair, genDilithiumKeypair } from '../services/pqcService.js';
import { performance } from 'perf_hooks';

// Compute __dirname in ESM:
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const DB_PATH    = path.resolve(__dirname, '../../db.json');

function loadDB() {
  if (!fs.existsSync(DB_PATH)) return {};
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
}

export default {
  async register(req, res) {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ error: 'Missing userId' });
    }

    // Time Kyber
    const t0 = performance.now();
    const kyber = await genKyberKeypair();
    const t1 = performance.now();

    // Time Dilithium
    const dilithium = await genDilithiumKeypair();
    const t2 = performance.now();

    // Encode keys
    const pubKyberB64   = Buffer.from(kyber.publicKey).toString('base64');
    const secKyberB64   = Buffer.from(kyber.secretKey).toString('base64');
    const pubDilithB64  = Buffer.from(dilithium.publicKey).toString('base64');
    const privDilithB64 = Buffer.from(dilithium.privateKey).toString('base64');

    const serverMetrics = {
      kyberGenMs:       +((t1 - t0).toFixed(2)),
      dilithiumGenMs:   +((t2 - t1).toFixed(2)),
      kyberPubKeyBytes:      kyber.publicKey.length,
      kyberSecKeyBytes:      kyber.secretKey.length,
      dilithiumPubKeyBytes:  dilithium.publicKey.length,
      dilithiumPrivKeyBytes: dilithium.privateKey.length,
    };

    // Persist to db.json
    const db = loadDB();
    db[userId] = {
      publicKeys: { kyber: pubKyberB64,    dilithium: pubDilithB64 },
      privateKeys:{ kyber: secKyberB64,    dilithium: privDilithB64 },
    };
    saveDB(db);

    // Respond
    res.json({
      userId,
      publicKeys:  db[userId].publicKeys,
      privateKeys: db[userId].privateKeys,
      serverMetrics,
    });
  }
};
