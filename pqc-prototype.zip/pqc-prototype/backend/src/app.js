import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';

import registerCtrl from './controllers/authController.js';
import { generateProofHandler } from './controllers/zkProofController.js';  // ← import proof handler

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Health-check
app.get('/', (req, res) => {
  res.send('✅ PQC backend is up and running');
});

// Keygen endpoint
app.post('/api/auth/register', registerCtrl.register);

// ZK-STARK proof endpoint
app.post('/api/generate-proof', generateProofHandler);     // ← add this line

// Listen on all interfaces so other devices can reach it
const PORT = 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🛡 PQC backend listening on http://0.0.0.0:${PORT}`);
});
