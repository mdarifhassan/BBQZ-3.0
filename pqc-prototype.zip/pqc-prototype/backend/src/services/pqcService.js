// backend/src/services/pqcService.js

// crystals-kyber is ESM-friendly:
import kyber from 'crystals-kyber';

// dilithium-crystals is CJS, so grab its default and then the named export:
import dilithiumPkg from 'dilithium-crystals';
const { dilithium } = dilithiumPkg;

/**
 * Generate a Kyber key-pair.
 */
export async function genKyberKeypair() {
  const [publicKey, secretKey] = kyber.KeyGen768();
  return { publicKey, secretKey };
}

/**
 * Encapsulate (encrypt).
 */
export async function encapsulate(publicKey) {
  const [cipherText, sharedSecret] = kyber.Encrypt768(publicKey);
  return { cipherText, sharedSecret };
}

/**
 * Decapsulate (decrypt).
 */
export async function decapsulate(cipherText, secretKey) {
  return kyber.Decrypt768(cipherText, secretKey);
}

/**
 * Generate a Dilithium key-pair.
 */
export async function genDilithiumKeypair() {
  const keyPair = await dilithium.keyPair();
  return { publicKey: keyPair.publicKey, privateKey: keyPair.privateKey };
}

/**
 * Sign a message.
 */
export async function sign(message, privateKey) {
  return await dilithium.sign(message, privateKey);
}

/**
 * Verify a signed message.
 */
export async function verify(signedMessage, publicKey) {
  return await dilithium.open(signedMessage, publicKey);
}
