use zkstark::prove_secret_from_id;
use core::pedersen::pedersen;

#[test]
fn test_proof_validity() {
    let user_id: felt252 = 42;
    let proof = prove_secret_from_id(user_id);

    let expected_secret = pedersen(user_id, 0);
    let expected_output = expected_secret * expected_secret;

    assert(proof.output == expected_output, 'Proof failed');
}
