use core::pedersen::pedersen;

#[derive(Copy, Drop)]
pub struct PublicProof {
    pub id: felt252,
    pub output: felt252, // public = secret^2
}

/// Simulates a ZK proof: private key derived from user ID is squared and returned
pub fn prove_secret_from_id(user_id: felt252) -> PublicProof {
    let secret: felt252 = pedersen(user_id, 0); // Simulated post-quantum private key
    let output: felt252 = secret * secret;      // Public output for ZK-style verification

    PublicProof {
        id: user_id,
        output: output
    }
}
